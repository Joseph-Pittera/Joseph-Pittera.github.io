var app = {
  init: function () {
    console.log('init !');
  }
};

document.addEventListener('DOMContentLoaded', app.init);